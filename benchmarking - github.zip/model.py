import torch.nn as nn
from dataset import *


class ConvLSTM(nn.Module):
    def __init__(self, **kwargs):
        super(ConvLSTM, self).__init__()
        self.pooling = kwargs['pooling']
        self.num_layer = kwargs['num_layer']
        self.conv1 = nn.Conv1d(kwargs['input_dim'], kwargs['conv_dim'], kernel_size=3, padding=1,
                               padding_mode='replicate')
        self.conv2 = nn.Conv1d(kwargs['conv_dim'], kwargs['conv_dim'], kernel_size=3, padding=1,
                               padding_mode='replicate')
        self.conv3 = nn.Conv1d(kwargs['conv_dim'], kwargs['conv_dim'], kernel_size=3, padding=1,
                               padding_mode='replicate')
        self.pool = nn.MaxPool1d(kernel_size=3, stride=3)
        self.lstm = nn.LSTM(kwargs['conv_dim'], kwargs['hidden_dim'], kwargs['num_lstm_layers'], batch_first=True)
        self.hidden2pred = nn.Linear(kwargs['hidden_dim'], kwargs['pred_length'])
        self.dropout = nn.Dropout(kwargs['dropout_rate'])

    def forward(self, x):
        x = self.conv1(x.permute(0, 2, 1))
        if self.pooling:
            x = self.pool(x)
        if self.num_layer > 1:
            x = self.conv2(x)
            if self.pooling:
                x = self.pool(x)
        if self.num_layer > 2:
            x = self.conv3(x)
            if self.pooling:
                x = self.pool(x)
        x = x.permute(0, 2, 1)
        h, _ = self.lstm(x)
        last_h = self.dropout(h[:, -1, :])  # batch first = True
        pred = self.hidden2pred(last_h)
        return pred


class LSTM(nn.Module):
    def __init__(self, **kwargs):
        super(LSTM, self).__init__()
        self.lstm = nn.LSTM(kwargs['input_dim'], kwargs['hidden_dim'], kwargs['num_lstm_layers'], batch_first=True)
        self.hidden2pred = nn.Linear(kwargs['hidden_dim'], kwargs['pred_length'])
        self.dropout = nn.Dropout(kwargs['dropout_rate'])

    def forward(self, x):
        h, _ = self.lstm(x)
        last_h = self.dropout(h[:, -1, :])  # batch first = True
        pred = self.hidden2pred(last_h)
        return pred


if __name__ == '__main__':
    global_cfg = load_json('./notebooks/global_cfg.json')

    train_dataset, test_dataset, dataset, train_idx, val_idx = get_datasets(site_name='军功', **global_cfg)
    dataloader = DataLoader(train_dataset, batch_size=global_cfg['batch_size'])

    x, y, date = next(iter(dataloader))
    print(x.shape, y.shape)

    model = ConvLSTM(input_dim=x.shape[-1], **global_cfg)
    pred = model(x)
    print(pred.shape)

    model = LSTM(input_dim=x.shape[-1], **global_cfg)
    pred = model(x)
    print(pred.shape)

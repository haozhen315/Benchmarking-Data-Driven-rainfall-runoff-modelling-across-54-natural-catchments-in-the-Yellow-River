import sys
from train import *
from file_operation import *

site_names = load_list('./data/basin_ids.txt')


def create_globale_cfgs() -> list:
    global_cfgs = []
    global_cfg = load_json('./cfg/global_cfg.json')
    global_cfg['device'] = 'cuda' if torch.cuda.is_available() else 'cpu'

    site_name = global_cfg['site_name']
    batch_size = global_cfg['batch_size']
    conv_dim = global_cfg['conv_dim']
    input_seq_length = global_cfg['input_seq_length']
    lag = global_cfg['lag']
    num_layer = global_cfg['num_layer']
    test_loc = global_cfg['test_loc']
    forcing_only = global_cfg['forcing_only']

    global_cfgs.append(global_cfg)
    global_cfg[
        'save_dir'] = f'./exps/{site_name}/batch_size={batch_size}_conv_dim={conv_dim}_input_seq_length={input_seq_length}_' \
                      f'lag={lag}_num_layer={num_layer}_test_loc={test_loc}_site_name={site_name}_forcing_only={forcing_only}'

    global_cfgs.append(global_cfg.copy())

    return global_cfgs


def train_global_cfg(global_cfg):
    creat_exp_dir(global_cfg['save_dir'])
    train(**global_cfg)


def train_group(global_cfgs):
    for global_cfg in tqdm(global_cfgs):
        train_global_cfg(global_cfg)


def split(a, n):
    k, m = divmod(len(a), n)
    return (a[i * k + min(i, m):(i + 1) * k + min(i + 1, m)] for i in range(n))


if __name__ == '__main__':
    global_cfgs = create_globale_cfgs()

    # Here is to facilitate the opening of multiple tabs for multi-process training
    num_groups = 5
    groups = list(split(global_cfgs, num_groups))

    # python main.py [0 1 2 3 4]
    group_id = int(sys.argv[1])
    train_group(groups[group_id])

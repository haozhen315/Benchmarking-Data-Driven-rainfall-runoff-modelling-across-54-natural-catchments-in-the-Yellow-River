def load_list(path):
    score = []
    with open(path, "r", encoding='gbk') as f:
        for line in f:
            score.append(line.strip())
    return score


def save_list(l, path):
    with open(path, "w") as f:
        for s in l:
            f.write(str(s) + "\n")


def load_json(path):
    import json
    with open(path, "r", encoding='utf8') as read_file:
        data = json.load(read_file)
    return data


def save_json(dic, save_path):
    import json
    with open(save_path, 'w', encoding='utf8') as outfile:
        json.dump(dic, outfile, indent=4, sort_keys=True, default=str, ensure_ascii=False)


def absoluteFilePaths(directory):
    import os
    def absoluteFilePaths(directory):
        for dirpath, _, filenames in os.walk(directory):
            for f in filenames:
                yield os.path.abspath(os.path.join(dirpath, f))

    return list(absoluteFilePaths(directory))

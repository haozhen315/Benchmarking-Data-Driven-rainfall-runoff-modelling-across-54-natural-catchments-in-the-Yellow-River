import os
import time

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd


def creat_train_val_data(train_dataloader, val_dataloader):
    X_train = []
    X_test = []
    y_train = []
    y_test = []

    for ix, batch in enumerate(iter(train_dataloader)):
        x, y, date = batch
        x = np.array(x).flatten()
        y = np.array(y).flatten()

        X_train.append(x)
        y_train.append(y)

    for ix, batch in enumerate(iter(val_dataloader)):
        x, y, date = batch
        x = np.array(x).flatten()
        y = np.array(y).flatten()

        X_test.append(x)
        y_test.append(y)

    X_train, y_train = np.array(X_train), np.array(y_train).reshape(-1, )
    X_test, y_test = np.array(X_test), np.array(y_test).reshape(-1, )
    return X_train, X_test, y_train, y_test


def plot_result(save_dir, dataset, train_idx, val_idx, train_preds, train_obs, val_preds, val_obs):
    df_train = pd.DataFrame(data=np.array([train_preds, train_obs]).T,
                            index=pd.DatetimeIndex(np.array(dataset.dates)[train_idx]),
                            columns=["train_preds", "train_obs"])
    df_val = pd.DataFrame(data=np.array([val_preds, val_obs]).T,
                          index=pd.DatetimeIndex(np.array(dataset.dates)[val_idx]),
                          columns=["val_preds", "val_obs"])

    plt.figure(figsize=(10, 7))

    plt.subplot(211)
    plt.title('train')
    plt.plot(df_train)

    plt.subplot(212)
    plt.title('validation')
    plt.plot(df_val)

    save_path = os.path.join(save_dir, f'{time.time()}.png')
    plt.savefig(save_path, dpi=100, facecolor='white')
    plt.close()

import matplotlib
import matplotlib.pyplot as plt
import torch.nn as nn
from hydroeval import kge
from torch import optim
from tqdm import tqdm
from torch.utils.data import DataLoader
from file_operation import *
from dataset import *
from metrics import *
from model import ConvLSTM, LSTM

matplotlib.use('Agg')


def train_batch(x, y, model, optimizer, loss_fn):
    model.train()
    prediction = model(x)
    batch_loss = loss_fn(prediction.flatten(), y.flatten())
    batch_loss.backward()
    optimizer.step()
    optimizer.zero_grad()
    return batch_loss.item()


def get_data(**kwargs):
    train_dataset, val_dataset, dataset, train_idx, val_idx = get_datasets(**kwargs)
    train_dataloader = DataLoader(train_dataset, batch_size=kwargs['batch_size'])
    val_dataloader = DataLoader(val_dataset, batch_size=kwargs['batch_size'])
    return train_dataloader, val_dataloader, dataset, train_idx, val_idx


def get_model(train_dataloader, **kwargs):
    x, y, date = next(iter(train_dataloader))
    if kwargs['model'] == 'conv_lstm':
        model = ConvLSTM(input_dim=x.shape[-1], **kwargs).to(kwargs['device'])
    elif kwargs['model'] == 'lstm':
        model = LSTM(input_dim=x.shape[-1], **kwargs).to(kwargs['device'])
    loss_func = nn.MSELoss()
    optimizer = optim.Adam(model.parameters())
    return model, optimizer, loss_func


@torch.no_grad()
def val_loss(x, y, model, loss_func):
    model.eval()
    prediction = model(x)
    val_loss = loss_func(prediction.flatten(), y.flatten())
    return val_loss.item()


@torch.no_grad()
def model_preds_obs(x, y, model):
    model.eval()
    prediction = model(x)
    return prediction, y


def val_metircs_func(obs, preds):
    return {'calc_bias_error': calc_bias_error(obs, preds),
            'calc_std_error': calc_std_error(obs, preds),
            'calc_alpha_nse': calc_alpha_nse(obs, preds),
            'calc_beta_nse': calc_beta_nse(obs, preds),
            'calc_correlation': calc_correlation(obs, preds),
            'calc_fdc_fhv': calc_fdc_fhv(obs, preds),
            'calc_fdc_flv': calc_fdc_flv(obs, preds),
            'calc_fdc_fms': calc_fdc_fms(obs, preds),
            'calc_nse': calc_nse(obs, preds),
            'kge': kge(preds, obs)}


def restore_scale(arr, dataset):
    arr = np.array(arr)
    return arr * dataset.stds['q'] + dataset.means['q']


def print_var(variable):
    def namestr(obj, namespace=globals()):
        return [name for name in namespace if namespace[name] is obj]

    print(namestr(variable)[0], '=', variable)


def plot_epoch(save_dir, epoch, dataset, train_idx, val_idx, train_preds, train_obs, val_preds, val_obs, train_losses,
               val_losses, train_nses, val_nses):
    df_train = pd.DataFrame(data=np.array([train_preds, train_obs]).T,
                            index=pd.DatetimeIndex(np.array(dataset.dates)[train_idx]),
                            columns=["train_preds", "train_obs"])
    df_val = pd.DataFrame(data=np.array([val_preds, val_obs]).T,
                          index=pd.DatetimeIndex(np.array(dataset.dates)[val_idx]),
                          columns=["val_preds", "val_obs"])

    plt.figure(figsize=(20, 20))

    plt.subplot(611)
    plt.title('train')
    plt.plot(df_train)

    plt.subplot(612)
    plt.title('validation')
    plt.plot(df_val)

    plt.subplot(613)
    plt.title('train_losses')
    plt.plot(train_losses)

    plt.subplot(614)
    plt.title('train_nses')
    plt.plot(train_nses)

    plt.subplot(615)
    plt.title('val_losses')
    plt.plot(val_losses)

    plt.subplot(616)
    plt.title('val_nses')
    plt.plot(val_nses)

    plt.savefig(os.path.join(save_dir, f'epoch_{epoch}.png'), dpi=100, facecolor='white')
    plt.close()


def save_epoch(train_losses, train_nses, val_losses, val_nses, val_metircs, epoch, **kwargs):
    save_dict = {
        'global_cfg': kwargs,
        'train_losses': train_losses,
        'train_nses': train_nses,
        'val_losses': val_losses,
        'val_nses': val_nses,
        'val_metircs': val_metircs,
        'best_val_metric': val_metircs[np.argmax(val_nses)]
    }
    save_json(save_dict, os.path.join(kwargs['save_dir'], f'epoch_{epoch}.json'))
    print(save_dict['best_val_metric'])


@torch.no_grad()
def eval_train(model, train_dataloader, dataset):
    model.eval()
    train_preds, train_obs = [], []
    for ix, batch in enumerate(iter(train_dataloader)):
        x, y, date = batch

        pred = model(x).detach().cpu().numpy().flatten()
        pred = restore_scale(pred, dataset)
        train_preds.extend(pred)

        y = y.detach().cpu().numpy().flatten()
        y = restore_scale(y, dataset)
        train_obs.extend(y)

    train_epoch_nse = calc_nse(np.array(train_obs), np.array(train_preds))
    return train_preds, train_obs, train_epoch_nse


@torch.no_grad()
def eval_val(model, val_dataloader, loss_func, dataset):
    model.eval()
    val_preds, val_obs, validation_epoch_losses = [], [], []

    for ix, batch in enumerate(iter(val_dataloader)):
        x, y, date = batch
        validation_loss = val_loss(x, y, model, loss_func)
        validation_epoch_losses.append(validation_loss)

        pred = model(x).detach().cpu().numpy().flatten()
        pred = restore_scale(pred, dataset)
        val_preds.extend(pred)

        y = y.detach().cpu().numpy().flatten()
        y = restore_scale(y, dataset)
        val_obs.extend(y)

    val_epoch_nse = calc_nse(np.array(val_obs), np.array(val_preds))
    return val_preds, val_obs, np.mean(validation_epoch_losses), val_epoch_nse


def train(**kwargs):
    print(kwargs)

    # data
    train_dataloader, val_dataloader, dataset, train_idx, val_idx = get_data(**kwargs)

    # model
    model, optimizer, loss_func = get_model(train_dataloader, **kwargs)

    # scheduler
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer,
                                                     factor=0.5,
                                                     patience=int(50000 / len(dataset)),
                                                     threshold=0.001, verbose=True,
                                                     min_lr=1e-5)

    train_losses, train_nses = [], []
    val_losses, val_nses = [], []
    val_metircs = []
    for epoch in tqdm(range(kwargs['num_epoch'])):
        # train
        train_epoch_losses, train_epoch_nses = [], []
        for ix, batch in enumerate(iter(train_dataloader)):
            x, y, date = batch
            batch_loss = train_batch(x, y, model, optimizer, loss_func)
            train_epoch_losses.append(batch_loss)
        train_epoch_loss = np.array(train_epoch_losses).mean()

        # train eval
        train_preds, train_obs, train_epoch_nse = eval_train(model, train_dataloader, dataset)

        # val eval
        val_preds, val_obs, validation_epoch_loss, val_epoch_nse = eval_val(model, val_dataloader, loss_func, dataset)

        # scheduler update
        scheduler.step(validation_epoch_loss)

        # metircs update
        val_metircs.append(val_metircs_func(np.array(val_obs), np.array(val_preds)))

        train_losses.append(train_epoch_loss)
        train_nses.append(train_epoch_nse)
        val_losses.append(validation_epoch_loss)
        val_nses.append(val_epoch_nse)

        # log
        log_freq = 1
        if epoch % log_freq == 0:
            plot_epoch(kwargs['save_dir'], epoch, dataset, train_idx, val_idx, train_preds, train_obs, val_preds,
                       val_obs, train_losses, val_losses, train_nses, val_nses)
            save_epoch(train_losses, train_nses, val_losses, val_nses, val_metircs, epoch, **kwargs)

        # termination condition
        if (scheduler.num_bad_epochs == scheduler.patience) and (
                optimizer.param_groups[0]['lr'] == scheduler.min_lrs[0]):
            break


def creat_exp_dir(dir):
    if not os.path.exists(dir):
        os.makedirs(dir)
        print(dir, ' created')
    else:
        print(dir, ' exists')

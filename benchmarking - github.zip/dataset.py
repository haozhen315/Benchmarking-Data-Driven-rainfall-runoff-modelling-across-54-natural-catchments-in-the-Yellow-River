import datetime
import pandas as pd
import numpy as np
import torch
from torch.utils.data import Dataset
from torch.utils.data import Subset
import os


class Dataset(Dataset):
    def __init__(self, data_dir, **kwargs):
        forcing, streamflow = self.get_input(data_dir, kwargs['site_name'])

        daily_streamflow = streamflow.resample('D').mean().dropna()
        interpolated_forcing = forcing.resample('D').mean().interpolate().dropna()
        interpolated_streamflow = streamflow.resample('D').mean().interpolate().dropna()
        lagged_interpolated_streamflow = interpolated_streamflow.copy()
        lagged_interpolated_streamflow.index = interpolated_streamflow.index + datetime.timedelta(days=1)
        merged_input = pd.merge(left=lagged_interpolated_streamflow, right=interpolated_forcing, on='date')

        self.means = merged_input.mean()
        self.stds = merged_input.std()
        normalized_merged_input = (merged_input - self.means) / self.stds

        self.xs = []
        self.ys = []
        self.dates = []
        for date_index in daily_streamflow.index:
            sample_input = normalized_merged_input.loc[
                           date_index - datetime.timedelta(kwargs['input_seq_length'] - 1): date_index]
            q = daily_streamflow.loc[date_index][0]
            q = (q - self.means['q']) / self.means['q']
            if len(sample_input) < kwargs['input_seq_length']:
                continue
            assert len(sample_input) == kwargs['input_seq_length']
            if kwargs['forcing_only']:
                del sample_input['q']
            self.xs.append(torch.from_numpy(np.array(sample_input)).float().to(kwargs['device']))
            self.ys.append(torch.from_numpy(np.array(q)).float().to(kwargs['device']))
            self.dates.append(str(date_index)[:10])

    def __len__(self):
        return len(self.xs)

    def __getitem__(self, ix):
        return self.xs[ix], self.ys[ix], self.dates[ix]

    def get_input(self, data_dir, site_name):
        forcing_file = os.path.join(data_dir, site_name, 'forcing.xlsx')
        streamflow_file = os.path.join(data_dir, site_name, 'streamflow.xlsx')
        forcing_df = pd.read_excel(forcing_file, engine='openpyxl').set_index('date')
        forcing_df.index = pd.DatetimeIndex(forcing_df.index)
        streamflow_df = pd.read_excel(streamflow_file, engine='openpyxl').set_index('date')
        streamflow_df.index = pd.DatetimeIndex(streamflow_df.index)
        return forcing_df.sort_index(), streamflow_df.sort_index()


def get_datasets(site_name, **kwargs):
    dataset = Dataset(site_name=site_name,
                      data_dir=kwargs['data_dir'],
                      input_seq_length=kwargs['input_seq_length'],
                      device=kwargs['device'],
                      lag=kwargs['lag'],
                      forcing_only=kwargs['forcing_only']
                      )
    test_length = max(365, min(int(len(dataset) * kwargs['test_prop']), 365 * 3))  # Up to 3 years, minimum 1 year
    all_index = list(range(len(dataset)))

    if kwargs['test_loc'] == -1:
        val_idx = all_index[-test_length:]
    elif kwargs['test_loc'] == -2:
        val_idx = all_index[-2 * test_length: -test_length]
    train_idx = [index for index in all_index if index not in val_idx]

    train_dataset, test_dataset = Subset(dataset, train_idx), Subset(dataset, val_idx)
    return train_dataset, test_dataset, dataset, train_idx, val_idx
